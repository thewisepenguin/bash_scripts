import React, { Component } from "react";
import axios from "axios";

class MyForm extends Component {
  constructor() {
    super();
    this.state = {
      first: "",
      second: "",
      result: "",
    };
  }

  onChange = (e) => {
    /*
        Because we named the inputs to match their
        corresponding values in state, it's
        super easy to update the state
      */
    this.setState({ [e.target.name]: e.target.value });
  };

  onSubmit = (e) => {
    e.preventDefault();
    // get our form data out of state
    var first = this.state.first;
    var second = this.state.second;
    // var body = ({ first, second } = (this.state.first, this.state.second));
    // alert(JSON.stringify({ first, second }));
    axios({
      method: "POST",
      url: "http://localhost:5000/api/Calc",
      data: JSON.stringify({ first, second }),
    }).then((response) => {
      this.setState({ result: response.result });
    });
  };

  render() {
    const { first, second } = this.state;
    return (
      <form onSubmit={this.onSubmit}>
        <p>First Number:</p>
        <input
          type="text"
          name="first"
          value={first}
          onChange={this.onChange}
        />
        <br></br>
        <br></br>
        <p>Second Number:</p>
        <input
          type="text"
          name="second"
          value={second}
          onChange={this.onChange}
        />
        <br></br>
        <br></br>
        <button type="submit">Submit</button>
        <br></br>
        <br></br>
        <p>result:</p>
        <p>{this.state.result}</p>
      </form>
    );
  }
}

class Version extends Component {
  constructor(props) {
    super(props);
    this.state = {
      version: "",
    };
  }

  componentDidMount() {
    axios.get("http://localhost:5000/api/Test").then((res) => {
      this.setState({ version: res.data });
    });
  }

  render() {
    return (
      <div>
        <footer>
          <p>Build number:</p>
          {this.state.version}
        </footer>
      </div>
    );
  }
}

export { MyForm, Version };
