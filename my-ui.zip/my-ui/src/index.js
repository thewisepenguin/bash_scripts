import React from "react";
import ReactDOM from "react-dom";
import App, { Version, MyForm } from "./App";

ReactDOM.render(
  <div>
    <MyForm></MyForm>
    <Version></Version>
  </div>,
  document.getElementById("root")
);
