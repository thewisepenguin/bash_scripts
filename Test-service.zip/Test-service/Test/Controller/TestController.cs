﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Test.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {

        public string getVersion(string path)

        {

            string version = System.IO.File.ReadAllText(path);

            return version;

        }

        [HttpGet]
        public string getVersion()
        {

            var dir = System.Reflection.Assembly.GetExecutingAssembly().Location;

            string path = System.IO.Path.GetDirectoryName(dir);

            string buildnumber = getVersion(Path.Combine(Directory.GetParent(path).ToString(), "buildnumber"));

            return buildnumber;
        }
    }
}
