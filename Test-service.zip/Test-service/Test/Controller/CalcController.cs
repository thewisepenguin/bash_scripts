using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Calc.Controller
{
    [Route("api/[controller]")]
    [ApiController]

    public class CalcController : ControllerBase
    {

        [HttpPost]
        public string add([FromBody] ParamObj data)

        {
            var x = new { name = data.first, family = data.second };
            //  var d = JsonConvert.SerializeObject(data);

            // da =JsonConvert.DeserializeObject<JObject>(d);

            // Console.Write(d.All);
            // int result = (first + second);

            return x.ToString();

        }

        public class ParamObj
        {
            public string first { get; set; }
            public string second { get; set; }

        }

        // [HttpGet]

        // public string getget()
        // {
        //     return "Hi";
        // }
    }
}


