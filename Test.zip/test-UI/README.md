h1. TODOs

* Recreate storage grid page if needed, If not possibly remove Ag-Grid
* check to see if Ag-Grid is useful anywhere
* Recreate resource table, If not possibly remove ReactTable
* check to see if ReactTable is useful anywhere
* Update health page, use react version of am-charts, remove lodash and charts from utils
* Recreate storage and hard detail pages
* Fix DashboardProcessRecentFilePage.jsx , possibly remove moment and moment-jalali, or encapsulate in a component
* Unify all date pickers used in project: rc-time-picker react-persian-date-picker
* Merge all 'FileSearchContainer's
* Check what's going on with all engine statuses, what is vish-?