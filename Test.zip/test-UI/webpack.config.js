var path = require('path');

module.exports = {
    context: path.join(__dirname, "src"),
    entry: "./index.jsx",
    output: {
        path: __dirname + "/public/assets/",
        publicPath: "/assets/",
        filename: "bundle.js"
    },
    resolve: {
        extensions: ["", ".js", ".jsx", ".css"]
    },
    module: {
        loaders: [
            { test: /\.jsx$/, loader: "babel" },
            { test: /\.css$/, loader: "style!css" },
            { test: /\.less$/, loader: "style!css!less" },
            { test: /\.scss$/, loader: "style!css!sass" },
            { test: /\.svg(\?[a-z0-9=.]+)?$/, loader: "url?limit=5000" },
            { test: /\.(woff|woff2)(\?[a-z0-9=.]+)?$/, loader: "url-loader?limit=10000&mimetype=application/font-woff" },
            { test: /\.ttf(\?[a-z0-9=.]+)?$/, loader: "file-loader" },
            { test: /\.eot(\?[a-z0-9=.]+)?$/, loader: "file-loader" }
        ]
    },
    devServer: {
        historyApiFallback: true
    }
};
